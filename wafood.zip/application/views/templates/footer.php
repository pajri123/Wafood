<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2023 &copy; Wafood</p>
        </div>
        <div class="float-end">
            <p>
                Crafted with
                <span class="text-danger"><i class="bi bi-heart-fill icon-mid"></i></span>
                by <a href="">Pajri Nur Iqrom Uye</a>
            </p>
        </div>
    </div>
</footer>
</div>
</div>
<script src="<?= base_url() . 'dist/'; ?>assets/compiled/js/jquery.slim.min.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/compiled/js/bootstrap-input-spinner.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/compiled/js/app.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/compiled/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/compiled/js/select2.full.min.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/extensions/sweetalert2/sweetalert2.min.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/extensions/toastify-js/src/toastify.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/static/js/pages/sweetalert2.js"></script>
<script>
    <?= $this->session->flashdata('toast'); ?>
</script>
<script src="<?= base_url() . 'dist/'; ?>assets/static/js/components/dark.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js"></script>


<!-- Need: Apexcharts -->
<script src="<?= base_url() . 'dist/'; ?>assets/extensions/simple-datatables/umd/simple-datatables.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/static/js/pages/simple-datatables.js"></script>
<script src="<?= base_url() . 'dist/'; ?>assets/extensions/@fortawesome/fontawesome-free/js/all.min.js"></script>
</body>

</html>